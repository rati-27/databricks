# Databricks notebook source
# MAGIC %run ../../Includes/dlt-setup

# COMMAND ----------

File.newData()


