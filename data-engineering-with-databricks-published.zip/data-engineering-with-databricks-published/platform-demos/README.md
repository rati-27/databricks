# Platform Demos

This collection of markdown files and assets is provided for reference by instructors and students as part of the Data Engineering with Databricks course.
